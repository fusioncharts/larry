describe('jasmine-node-nested', function(){
  it('should pass', function(){
    expect(1+2).toEqual(3);
  });
});
