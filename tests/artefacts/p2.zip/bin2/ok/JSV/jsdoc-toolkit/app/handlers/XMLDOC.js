/**
 * This is the main container for the XMLDOC handler.
 * @namespace
 * @author Brett Fattori (bfattori@fry.com)
 * @version $Revision: 498 $
 */
XMLDOC = {
	
};

/** The current version string of this application. */
XMLDOC.VERSION = "1.0";

/** Include the library necessary to handle XML files */
IO.includeDir("handlers/XMLDOC/");

/**
 * @type Symbol[]
 */
XMLDOC.handle = function(srcFile, src) {
	
};

XMLDOC.publish = function(symbolgroup) {
	
}